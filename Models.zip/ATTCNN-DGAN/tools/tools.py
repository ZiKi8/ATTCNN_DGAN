import numpy as np
import pandas as pd
class TechnicalIndicatorGenerator:
    """
    A class to generate various technical indicators used in financial analysis.
    """
    def __init__(self):
        pass
    
    def fourier_transform(self,data, num_, window=200):
        """
        Causal rolling FFT reconstruction; warm-up period filled with original data.
        No leakage, but warm-up values are trivially exact.
        """
        data = np.asarray(data, dtype=float)
        T = len(data)

        # Fill warm-up with original values
        reconstructed = data.copy()

        for t in range(window - 1, T):
            w = data[t - window + 1 : t + 1]   # past-only window

            fft_vals = np.fft.fft(w)
            fft_truncated = np.copy(fft_vals)
            fft_truncated[num_:-num_] = 0
            recon = np.fft.ifft(fft_truncated)

            reconstructed[t] = recon[-1].real  # align to current step

        return reconstructed

   
    
    
    def calculate_sma(self, data, window):
        """
        Calculate Simple Moving Average (SMA).

        Parameters:
        data (pd.Series): Time series data.
        window (int): Window size for moving average.

        Returns:
        pd.Series: SMA values.
        """
        return data.rolling(window=window).mean()

    def calculate_ema(self, data, window):
        """
        Calculate Exponential Moving Average (EMA).

        Parameters:
        data (pd.Series): Time series data.
        window (int): Span for exponential moving average.

        Returns:
        pd.Series: EMA values.
        """
        return data.ewm(span=window).mean()

    def calculate_macd(self, data, long_window, short_window, signal_window):
        """
        Calculate Moving Average Convergence Divergence (MACD).

        Parameters:
        data (pd.Series): Time series data.
        long_window (int): Span for the long EMA.
        short_window (int): Span for the short EMA.
        signal_window (int): Span for the signal line EMA.

        Returns:
        pd.Series: MACD signal line values.
        """
        short_ema = data.ewm(span=short_window).mean()
        long_ema = data.ewm(span=long_window).mean()
        macd_line = short_ema - long_ema
        return macd_line.ewm(span=signal_window).mean()

    def calculate_rsi(self, data, window):
        """
        Calculate Relative Strength Index (RSI).

        Parameters:
        data (pd.Series): Time series data.
        window (int): Window size for RSI calculation.

        Returns:
        pd.Series: RSI values.
        """
        delta = data.diff(1)
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.rolling(window=window).mean()
        avg_loss = loss.rolling(window=window).mean()
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    def calculate_atr(self, high, low, window):
        """
        Calculate Average True Range (ATR).

        Parameters:
        high (pd.Series): High prices.
        low (pd.Series): Low prices.
        window (int): Window size for ATR calculation.

        Returns:
        pd.Series: ATR values.
        """
        true_range = high - low
        return true_range.rolling(window=window).mean()

    def calculate_bollinger_bands(self, data, window):
        """
        Calculate Bollinger Bands.

        Parameters:
        data (pd.Series): Time series data.
        window (int): Window size for SMA and standard deviation.

        Returns:
        tuple: Upper band and lower band as pd.Series.
        """
        sma = data.rolling(window=window).mean()
        std_dev = data.rolling(window=window).std()
        upper_band = sma + 2 * std_dev
        lower_band = sma - 2 * std_dev
        return upper_band, lower_band

    def calculate_rsv(self, data, window):
        """
        Calculate Raw Stochastic Value (RSV).

        Parameters:
        data (pd.Series): Time series data.
        window (int): Window size for RSV calculation.

        Returns:
        pd.Series: RSV values.
        """
        rolling_min = data.rolling(window=window).min()
        rolling_max = data.rolling(window=window).max()
        return ((data - rolling_min) / (rolling_max - rolling_min)) * 100

   
    	
