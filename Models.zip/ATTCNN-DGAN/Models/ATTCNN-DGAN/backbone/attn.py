import math
import torch
import torch.nn as nn


class MultiHeadSelfAttentionKerasLike(nn.Module):
    """
    Emulates tf.keras.layers.MultiHeadAttention(num_heads, key_dim)
    with default output_dim = input_dim (query last dim).
    """
    def __init__(self, num_heads, key_dim, input_dim, dropout_rate=0.0):
        super().__init__()
        self.num_heads = num_heads
        self.key_dim = key_dim
        self.input_dim = input_dim
        self.inner_dim = num_heads * key_dim

        self.q_proj = nn.Linear(input_dim, self.inner_dim)
        self.k_proj = nn.Linear(input_dim, self.inner_dim)
        self.v_proj = nn.Linear(input_dim, self.inner_dim)
        self.out_proj = nn.Linear(self.inner_dim, input_dim)

        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        B, T, _ = x.shape

        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)

        q = q.view(B, T, self.num_heads, self.key_dim).transpose(1, 2)  # (B,H,T,D)
        k = k.view(B, T, self.num_heads, self.key_dim).transpose(1, 2)
        v = v.view(B, T, self.num_heads, self.key_dim).transpose(1, 2)

        scale = math.sqrt(self.key_dim)
        scores = torch.matmul(q, k.transpose(-1, -2)) / scale
        attn_weights = torch.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)

        context = torch.matmul(attn_weights, v)
        context = context.transpose(1, 2).contiguous().view(B, T, self.inner_dim)

        out = self.out_proj(context)
        return out


class TransformerEncoder2(nn.Module):
    """
    Matches your TF transformer_encoder2 behavior.
    """
    def __init__(self, d_model, num_heads, dff, input_dim=1, dropout_rate=0.0):
        super().__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.input_dim = input_dim
        self.dff = dff
        self.dropout_rate = dropout_rate

        self.ln1 = nn.LayerNorm(input_dim, eps=1e-6)

        self.mha = MultiHeadSelfAttentionKerasLike(
            num_heads=num_heads,
            key_dim=d_model,
            input_dim=input_dim,
            dropout_rate=dropout_rate
        )
        self.dropout_attn = nn.Dropout(dropout_rate)
        self.ln2 = nn.LayerNorm(input_dim, eps=1e-6)

        self.ffn_dense1 = nn.Linear(input_dim, dff)
        self.ffn_dense2 = nn.Linear(dff, d_model)
        self.dropout_ffn = nn.Dropout(dropout_rate)
        self.ln3 = nn.LayerNorm(d_model, eps=1e-6)

    def forward(self, x):
        x_norm = self.ln1(x)
        attn_out = self.mha(x_norm)
        attn_out = self.dropout_attn(attn_out)

        x2 = self.ln2(x_norm + attn_out)

        ffn_hidden = torch.relu(self.ffn_dense1(x2))
        ffn_out = self.ffn_dense2(ffn_hidden)
        ffn_out = self.dropout_ffn(ffn_out)

        x3 = self.ln3(x2 + ffn_out)

        x_mean = x3.mean(dim=1)  # (B, d_model)

        chunks = torch.chunk(x_mean, self.num_heads, dim=1)
        stacked = torch.stack(chunks, dim=0)
        output = stacked.mean(dim=0)  # (B, d_model/num_heads)

        return output.float()
