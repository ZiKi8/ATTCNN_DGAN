import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import mean_squared_error

from .data import set_seed, load_and_prepare_data
from .generator import Generator
from .discriminator import Discriminator


def gradient_penalty(discriminator, real_samples, fake_samples, device):
    batch_size = real_samples.size(0)

    epsilon = torch.rand(batch_size, 1, 1, device=device)
    interpolates = epsilon * real_samples + (1.0 - epsilon) * fake_samples
    interpolates.requires_grad_(True)

    critic_interpolates = discriminator(interpolates)
    grad_outputs = torch.ones_like(critic_interpolates, device=device)

    grads = torch.autograd.grad(
        outputs=critic_interpolates,
        inputs=interpolates,
        grad_outputs=grad_outputs,
        create_graph=True,
        retain_graph=True,
        only_inputs=True
    )[0]

    grads = grads.view(batch_size, -1)
    grad_norm = grads.norm(2, dim=1)
    gp = ((grad_norm - 1.0) ** 2).mean()
    return gp


def train_wgan_gp(
    train_x_slide,
    train_y_gan,
    device,
    steps,
    lambda_gp=0.5,
    batch_size=128,
    lr_g=0.000115,
    lr_d=0.000115,
    num_epochs=60,
    critic_iterations=5,
):
    train_loader = DataLoader(
        TensorDataset(train_x_slide, train_y_gan),
        batch_size=batch_size,
        shuffle=True
    )

    generator = Generator(
        input_channels=train_x_slide.shape[1],
        feature_size=train_x_slide.shape[2]
    ).to(device)

    discriminator = Discriminator(
        sequence_length=train_y_gan.shape[1]
    ).to(device)

    optimizerG = optim.Adam(generator.parameters(), lr=lr_g, betas=(0.0, 0.9))
    optimizerD = optim.Adam(discriminator.parameters(), lr=lr_d, betas=(0.0, 0.9))

    histG = np.zeros(num_epochs)
    histD = np.zeros(num_epochs)

    for epoch in range(num_epochs):
        loss_D_epoch = []
        loss_G_epoch = []

        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)

            # critic updates
            for _ in range(critic_iterations):
                optimizerD.zero_grad()

                fake_last = generator(xb)  # (B,1)
                fake_seq = torch.cat([yb[:, :steps, :], fake_last.view(-1, 1, 1)], dim=1)
                real_seq = yb

                critic_real = discriminator(real_seq)
                critic_fake = discriminator(fake_seq)

                wasserstein_loss = -(critic_real.mean() - critic_fake.mean())
                gp = gradient_penalty(discriminator, real_seq, fake_seq, device)

                lossD = wasserstein_loss + lambda_gp * gp
                lossD.backward()
                optimizerD.step()

            # generator update
            optimizerG.zero_grad()
            fake_last = generator(xb)
            fake_seq = torch.cat([yb[:, :steps, :], fake_last.view(-1, 1, 1)], dim=1)

            critic_fake = discriminator(fake_seq)
            lossG = -critic_fake.mean()
            lossG.backward()
            optimizerG.step()

            loss_D_epoch.append(lossD.item())
            loss_G_epoch.append(lossG.item())

        histD[epoch] = np.mean(loss_D_epoch)
        histG[epoch] = np.mean(loss_G_epoch)

        print(f"Epoch {epoch+1}/{num_epochs} | D loss: {histD[epoch]:.4f} | G loss: {histG[epoch]:.4f}")

    return generator, discriminator, histG, histD


def plot_losses(histG, histD, title):
    plt.figure(figsize=(12, 6))
    plt.plot(histG, label="Generator Loss")
    plt.plot(histD, label="Discriminator Loss")
    plt.title(title)
    plt.xlabel("Epochs")
    plt.legend(loc="upper right")
    plt.show()


def evaluate_and_plot(generator, x_slide, y_slide, y_scaler, device, title, ylabel):
    generator.eval()
    with torch.no_grad():
        pred = generator(x_slide.to(device)).cpu().numpy()

    y_true = y_scaler.inverse_transform(y_slide.numpy())
    y_pred = y_scaler.inverse_transform(pred)

    plt.figure(figsize=(12, 8))
    plt.plot(y_true, color="black", label="Actual Price")
    plt.plot(y_pred, color="blue", label="Predicted Price")
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xlabel("Days")
    plt.legend(loc="upper left")
    plt.show()

    rmse = mean_squared_error(y_true, y_pred, squared=False)
    acc = 1 - np.mean(np.abs((y_pred - y_true) / y_true))
    return rmse, acc, y_true, y_pred


def run_grid(
    symbol_list,
    steps_list,
    seeds,
    device,
    datasets_dir="../../Datasets",
    lambda_gp=0.5,
):
    for symbol in symbol_list:
        for steps in steps_list:
            re_train_error, re_train_acc = [], []
            re_test_error, re_test_acc = [], []

            for seed in seeds:
                print(f"\n=== Symbol: {symbol}, steps: {steps}, seed: {seed} ===")
                set_seed(seed)

                csv_path = f"{datasets_dir}/data{symbol}.csv"

                (
                    train_x_slide, train_y_slide, train_y_gan,
                    test_x_slide, test_y_slide, test_y_gan,
                    y_scaler
                ) = load_and_prepare_data(
                    csv_path=csv_path,
                    device=device,
                    steps=steps,
                )

                # train
                generator, discriminator, histG, histD = train_wgan_gp(
                    train_x_slide=train_x_slide,
                    train_y_gan=train_y_gan,
                    device=device,
                    steps=steps,
                    lambda_gp=lambda_gp,
                )

                plot_losses(histG, histD, title=f"WGAN-GP Loss ({symbol}, steps={steps}, seed={seed})")

                # eval train
                rmse_train, acc_train, y_train_true, y_train_pred = evaluate_and_plot(
                    generator,
                    train_x_slide,
                    train_y_slide,
                    y_scaler,
                    device,
                    title=f"{symbol} Training prediction (steps={steps}, seed={seed})",
                    ylabel=symbol
                )
                print(f"Training dataset RMSE: {rmse_train}")
                print(f"Training dataset accuracy: {acc_train}")

                # eval test
                rmse_test, acc_test, y_test_true, y_test_pred = evaluate_and_plot(
                    generator,
                    test_x_slide,
                    test_y_slide,
                    y_scaler,
                    device,
                    title=f"{symbol} Testing prediction (steps={steps}, seed={seed})",
                    ylabel=symbol
                )
                print(f"Testing dataset RMSE: {rmse_test}")
                print(f"Testing dataset accuracy: {acc_test}")

                # combined plot (train + test)
                plt.figure(figsize=(12, 6))
                plt.plot(np.arange(len(y_train_true)), y_train_true, color="black", label="Training Actual Price")
                plt.plot(np.arange(len(y_train_true)), y_train_pred, color="green", label="Training Predicted Price")

                offset = len(y_train_true)
                plt.plot(np.arange(offset, offset + len(y_test_true)), y_test_true, color="black", label="Testing Actual Price")
                plt.plot(np.arange(offset, offset + len(y_test_true)), y_test_pred, color="blue", label="Testing Predicted Price")

                plt.title(f"{symbol} prediction on training and testing (steps={steps}, seed={seed})")
                plt.xlabel("Time")
                plt.ylabel("Stock Price")
                plt.legend()
                plt.show()

                re_train_error.append(rmse_train)
                re_train_acc.append(acc_train)
                re_test_error.append(rmse_test)
                re_test_acc.append(acc_test)

            # save results per (symbol, steps)
            df = pd.DataFrame({
                "Seed": seeds,
                "Train Error": re_train_error,
                "Train Accuracy": re_train_acc,
                "Test Error": re_test_error,
                "Test Accuracy": re_test_acc
            })
            out_name = f"ATTCNN-DGANresults_{symbol}_{steps}.csv"
            df.to_csv(out_name, index=False)
            print(f"Results saved to {out_name}")
