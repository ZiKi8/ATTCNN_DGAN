import torch
import torch.nn as nn


class Discriminator(nn.Module):
    """
    Conv1D(32)->LReLU, Conv1D(64)->LReLU, Conv1D(128)->LReLU
    Flatten -> Dense(220)->LReLU -> Dense(220, relu) -> Dense(1)
    """
    def __init__(self, sequence_length: int):
        super().__init__()

        self.conv1 = nn.Conv1d(in_channels=1, out_channels=32, kernel_size=5, stride=1, padding=2)
        self.conv2 = nn.Conv1d(in_channels=32, out_channels=64, kernel_size=5, stride=1, padding=2)
        self.conv3 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=5, stride=1, padding=2)

        self.flatten = nn.Flatten()
        self.linear1 = nn.Linear(128 * sequence_length, 220)
        self.linear2 = nn.Linear(220, 220)
        self.linear3 = nn.Linear(220, 1)

        self.leaky_relu = nn.LeakyReLU(0.01)
        self.relu = nn.ReLU()

    def forward(self, x: torch.Tensor):
        # x: (B, T, 1) -> (B, 1, T)
        x = x.permute(0, 2, 1)
        x = self.leaky_relu(self.conv1(x))
        x = self.leaky_relu(self.conv2(x))
        x = self.leaky_relu(self.conv3(x))

        x = self.flatten(x)
        x = self.leaky_relu(self.linear1(x))
        x = self.relu(self.linear2(x))
        out = self.linear3(x)
        return out
