import random
import numpy as np
import pandas as pd
import torch

from sklearn.preprocessing import MinMaxScaler

from .attn import TransformerEncoder2


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def create_dataset(dataset: np.ndarray, time_step: int = 1):
    """
    dataset: numpy array (N, 1)
    returns:
      X: (N-time_step-1, time_step)
      y: (N-time_step-1,)
    """
    dataX, dataY = [], []
    for i in range(len(dataset) - time_step - 1):
        a = dataset[i:(i + time_step), 0]
        dataX.append(a)
        dataY.append(dataset[i + time_step, 0])
    return np.array(dataX), np.array(dataY)


def sliding_window_torch(x: np.ndarray, y: np.ndarray, window: int):
    """
    x: numpy array (N, n_features)
    y: numpy array (N, 1)
    Returns torch tensors:
      x_: (N-window, window, n_features)
      y_: (N-window, 1)
      y_gan: (N-window, window+1, 1)
    """
    x_, y_, y_gan = [], [], []
    for i in range(window, x.shape[0]):
        tmp_x = x[i - window: i, :]      # (window, n_features)
        tmp_y = y[i]                     # (1,)
        tmp_y_gan = y[i - window: i + 1] # (window+1, 1)
        x_.append(tmp_x)
        y_.append(tmp_y)
        y_gan.append(tmp_y_gan)

    x_ = torch.tensor(np.array(x_, dtype=np.float32))
    y_ = torch.tensor(np.array(y_, dtype=np.float32))
    y_gan = torch.tensor(np.array(y_gan, dtype=np.float32))
    return x_, y_, y_gan


def load_and_prepare_data(
    csv_path: str,
    device: torch.device,
    steps: int,
    time_step: int = 3,
    split_ratio: float = 0.8,
    d_model: int = 256,
    heads: int = 4,
    dff: int = 6,
    dropout_rate: float = 0.0,
):
    """
    Loads your CSV, selects features, extracts attention features from Close,
    concatenates them to original features, splits, scales, and builds sliding windows.

    Returns:
      train_x_slide, train_y_slide, train_y_gan,
      test_x_slide,  test_y_slide,  test_y_gan,
      y_scaler
    """
    data = pd.read_csv(csv_path)

    # set index
    data.index = data["Date"]
    data.drop(columns=["Date"], inplace=True)

    # remove columns with infinity
    columns_infinity = data.columns.to_series()[np.isinf(data).any()]
    data.drop(columns=columns_infinity, inplace=True)

    # select features (exactly as your code)
    data = data[[
        "Close", "pct_change",
        "log_change", "7sma", "14sma", "21sma", "7ema", "14ema", "21ema",
        "7macd", "14macd", "7rsi", "14rsi", "21rsi", "7atr", "14atr", "21atr",
        "7upper", "7lower", "14upper", "14lower", "21upper", "21lower", "7rsv",
        "14rsv", "21rsv", "3compo_FT", "6compo_FT", "9compo_FT", "27compo_FT",
        "81compo_FT", "100compo_FT"
    ]]

    # Close series for attention feature extraction
    data_transform = np.array(data["Close"]).reshape(-1, 1)

    # build supervised data for original features
    data["y"] = data["Close"]
    data = data.drop(columns=["Close"])
    x_later = data.iloc[:, :-1].values  # features
    y_later = data.iloc[:, -1].values   # y

    # build sequences from Close for attention feature extraction
    X_close, _ = create_dataset(data_transform, time_step=time_step)
    X_close = X_close.reshape(X_close.shape[0], X_close.shape[1], 1)  # (N, time_step, 1)

    transformer_model = TransformerEncoder2(
        d_model=d_model,
        num_heads=heads,
        dff=dff,
        input_dim=1,
        dropout_rate=dropout_rate
    ).to(device)

    transformer_model.eval()
    with torch.no_grad():
        X_tensor = torch.tensor(X_close, dtype=torch.float32, device=device)
        extracted_features_torch = transformer_model(X_tensor)  # (N, d_model/num_heads)
        extracted_features = extracted_features_torch.cpu().numpy()

    # align lengths and concatenate
    m = x_later.shape[0]
    n = extracted_features.shape[0]
    x_later = x_later[m - n:]  # align lengths
    y_later = y_later[m - n:]

    x_later = np.hstack([
        x_later.astype(np.float32),
        extracted_features.astype(np.float32)
    ])
    y_later = y_later.astype(np.float32)

    # split dataset & scale
    split = int(x_later.shape[0] * split_ratio)
    train_x, test_x = x_later[:split, :], x_later[split:, :]
    train_y, test_y = y_later[:split], y_later[split:]

    x_scaler = MinMaxScaler(feature_range=(0, 1))
    y_scaler = MinMaxScaler(feature_range=(0, 1))
    train_x = x_scaler.fit_transform(train_x)
    test_x = x_scaler.transform(test_x)
    train_y_scaled = y_scaler.fit_transform(train_y.reshape(-1, 1))
    test_y_scaled = y_scaler.transform(test_y.reshape(-1, 1))

    # sliding windows for WGAN-GP
    train_x_slide, train_y_slide, train_y_gan = sliding_window_torch(train_x, train_y_scaled, steps)
    test_x_slide, test_y_slide, test_y_gan = sliding_window_torch(test_x, test_y_scaled, steps)

    return (
        train_x_slide, train_y_slide, train_y_gan,
        test_x_slide, test_y_slide, test_y_gan,
        y_scaler
    )
