import torch
from backbone.train_loop import run_grid


def main():
    use_cuda = True
    device = torch.device("cuda" if torch.cuda.is_available() and use_cuda else "cpu")
    print("Using device:", device)

    seeds = [i for i in range(4)]
    steps_list = [2, 5, 10]
    symbol_list = ["AAPL", "META", "MSFT", "AMZN", "GOOG", "NVDA", "F", "TGT", "EL"]

    lambda_gp = 0.5

    run_grid(
        symbol_list=symbol_list,
        steps_list=steps_list,
        seeds=seeds,
        device=device,
        datasets_dir="../../Datasets",
        lambda_gp=lambda_gp
    )


if __name__ == "__main__":
    main()
